# Douban books from doulists and tags
Copyright (C) 2020 Jing Wang

### Books
Books_1, rating >= 0.0 and votes >= 0,&ensp;&ensp;&ensp;&ensp;number = 288824  
Books_2, rating >= 9.0 and votes >= 1000, number = 1742  
Books_3, rating >= 8.5 and votes >= 0,&ensp;&ensp;&ensp;&ensp;number = 62028  

Doulists:&ensp;&ensp;&thinsp;https://github.com/yuzhounh/Douban-books-2020/blob/master/Doulists_info  
Tags:&ensp;&ensp;&ensp;&ensp;&ensp;&thinsp;https://github.com/yuzhounh/Douban-books-2020/blob/master/Tags_info  
Algorithm: http://blog.sina.com.cn/s/blog_4cf3c50901031pf5.html  
Codes:&ensp;&ensp;&ensp;&ensp;https://github.com/yuzhounh/Douban-books-crawler-2020

### Contact information
Jing Wang  
wangjing@xynu.edu.cn  
yuzhounh@163.com  
2020-7-5 18:25:16
